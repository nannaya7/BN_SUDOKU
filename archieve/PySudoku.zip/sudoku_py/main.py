"""Main entry point for the warm 3D Sudoku game."""
from ui.game_window import GameWindow


def main():
    GameWindow().run()


if __name__ == "__main__":
    main()
