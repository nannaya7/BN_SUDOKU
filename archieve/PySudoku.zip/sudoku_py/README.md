# 수도쿠 · Warm 3D Sudoku (Pygame)

따뜻한 크림/테라코타 팔레트와 뉴모피즘(neumorphic) 스타일로 만든 Python Pygame 수도쿠 게임입니다.

## 설치

```bash
# 1. Python 3.9+ 필요
python --version

# 2. 의존성 설치
pip install -r requirements.txt
```

## 실행

```bash
python main.py
```

## 조작키

| 키 | 동작 |
| --- | --- |
| 마우스 클릭 | 셀 선택 / 버튼 클릭 |
| 숫자 1-9 | 숫자 입력 |
| Backspace / Delete / 0 | 숫자 지우기 |
| ← ↑ → ↓ | 셀 이동 |
| N | 메모(Notes) 모드 토글 |
| H | 힌트 (최대 3회) |
| U | 실행 취소 (Undo) |
| P | 일시정지 |
| ESC | 현재 난이도로 새 게임 |

## 프로젝트 구조

```
sudoku_py/
├── main.py                 # 엔트리 포인트
├── requirements.txt
├── README.md
├── core/                   # 게임 로직 (Flutter 포팅 시 재사용 가능)
│   ├── __init__.py
│   ├── sudoku_board.py     # 9x9 보드 관리
│   ├── sudoku_generator.py # 퍼즐 생성 (유일해 보장)
│   ├── sudoku_solver.py    # 백트래킹 솔버
│   └── game_state.py       # GameSession, GameState
├── ui/                     # Pygame UI 레이어
│   ├── __init__.py
│   ├── theme_manager.py    # 색상 / 폰트 / 레이아웃
│   ├── board_renderer.py   # 보드 그리기
│   ├── ui_components.py    # 버튼 / 패드 / 상태바 / 팝업
│   └── game_window.py      # 메인 루프 & 이벤트
└── utils/
    ├── __init__.py
    └── timer.py            # 경과 시간 추적
```

## 아키텍처

- **Core layer**: 순수 Python, UI 의존성 없음. Flutter/Dart로 1:1 포팅 가능.
- **UI layer**: Pygame 기반. `BoardRenderer`는 CustomPainter, `ui_components`는 위젯 대응.
- **Utils layer**: Timer 등 공통 유틸.

## 디자인

- 따뜻한 크림 배경(`#f2e6d3`) + 테라코타 포인트(`#a35c32`)
- 각 셀은 부드러운 그림자로 3D 블럭처럼 떠 있는 뉴모피즘 스타일
- 3x3 블록은 개별 컨테이너로 감싸 구분을 명확히 함
- 둥근 모서리와 부드러운 톤으로 공간감 표현

## 난이도

| 난이도 | 빈칸 수 |
| --- | --- |
| Easy | 35 |
| Medium | 45 |
| Hard | 55 |

모든 퍼즐은 유일해를 가집니다.
