"""UI components — 버튼, 숫자패드, 상태바, 팝업."""
import pygame
from typing import Callable, List, Optional, Tuple

from .theme_manager import ThemeManager
from core.game_state import GameSession, GameState


class Button:
    def __init__(
        self,
        rect: pygame.Rect,
        text: str,
        theme: ThemeManager,
        on_click: Optional[Callable] = None,
        primary: bool = False,
        font: Optional[pygame.font.Font] = None,
    ):
        self.rect = rect
        self.text = text
        self.t = theme
        self.on_click = on_click
        self.primary = primary
        self.hover = False
        self.active = False
        self.font = font or theme.font_small

    def draw(self, surface: pygame.Surface):
        t = self.t
        if self.primary:
            color = t.BUTTON_PRIMARY_DEEP if self.active else t.BUTTON_PRIMARY
            text_color = (253, 241, 223)
        else:
            if self.active:
                color = t.BUTTON_ACTIVE
            elif self.hover:
                color = t.BUTTON_HOVER
            else:
                color = t.BUTTON_COLOR
            text_color = t.TEXT_COLOR
        t.draw_soft_rect(surface, self.rect, color, radius=12, shadow_offset=3, shadow_alpha=55)
        text = self.font.render(self.text, True, text_color)
        surface.blit(text, text.get_rect(center=self.rect.center))

    def handle_event(self, ev: pygame.event.Event):
        if ev.type == pygame.MOUSEMOTION:
            self.hover = self.rect.collidepoint(ev.pos)
        elif ev.type == pygame.MOUSEBUTTONDOWN and ev.button == 1:
            if self.rect.collidepoint(ev.pos) and self.on_click:
                self.on_click()


class NumberPad:
    def __init__(self, theme: ThemeManager, origin: Tuple[int, int],
                 on_input: Callable[[int], None], on_erase: Callable):
        self.t = theme
        self.on_input = on_input
        self.on_erase = on_erase
        self.buttons: List[Button] = []
        size = 52
        gap = 8
        x0, y0 = origin
        for n in range(1, 10):
            col = (n - 1) % 9
            rect = pygame.Rect(x0 + col * (size + gap), y0, size, size)
            self.buttons.append(Button(
                rect, str(n), theme,
                on_click=(lambda nn=n: on_input(nn)),
                font=theme.font_medium,
            ))
        erase_rect = pygame.Rect(x0 + 9 * (size + gap), y0, size + 10, size)
        self.erase_btn = Button(erase_rect, "⌫", theme,
                                on_click=on_erase, font=theme.font_medium)

    def draw(self, surface: pygame.Surface, counts: List[int]):
        t = self.t
        for i, b in enumerate(self.buttons):
            b.draw(surface)
            remaining = 9 - counts[i + 1]
            if remaining >= 0:
                cnt = t.font_tiny.render(str(remaining), True, t.TEXT_MUTE)
                surface.blit(cnt, (b.rect.right - 14, b.rect.top + 4))
        self.erase_btn.draw(surface)

    def handle_event(self, ev):
        for b in self.buttons:
            b.handle_event(ev)
        self.erase_btn.handle_event(ev)


class StatusBar:
    """상단 상태바: 시간 / 난이도 / 실수횟수(하트) / 힌트."""

    def __init__(self, theme: ThemeManager):
        self.t = theme

    def draw(self, surface: pygame.Surface, session: GameSession):
        t = self.t
        labels = [
            ("TIME", session.timer.format()),
            ("MISTAKES", f"{session.mistakes}/{session.max_mistakes}"),
            ("HINTS", f"{session.max_hints - session.hints_used}"),
            ("LEVEL", session.difficulty.capitalize()),
        ]
        # 4 cards across top
        total_w = t.WIDTH - 80
        card_w = (total_w - 3 * 10) / 4
        y = 20
        h = 72
        for i, (lab, val) in enumerate(labels):
            x = 40 + i * (card_w + 10)
            rect = pygame.Rect(int(x), y, int(card_w), h)
            t.draw_soft_rect(surface, rect, (248, 234, 211), radius=12,
                             shadow_offset=3, shadow_alpha=55)
            lab_surf = t.font_tiny.render(lab, True, t.TEXT_MUTE)
            surface.blit(lab_surf, lab_surf.get_rect(midtop=(rect.centerx, rect.top + 10)))
            val_surf = t.font_medium.render(val, True, t.TEXT_COLOR)
            surface.blit(val_surf, val_surf.get_rect(midbottom=(rect.centerx, rect.bottom - 8)))


class Popup:
    @staticmethod
    def draw_overlay(surface: pygame.Surface, theme: ThemeManager,
                     title: str, message: str):
        overlay = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
        overlay.fill((242, 230, 211, 220))
        surface.blit(overlay, (0, 0))
        # card
        w, h = 380, 180
        x = (surface.get_width() - w) // 2
        y = (surface.get_height() - h) // 2
        rect = pygame.Rect(x, y, w, h)
        theme.draw_soft_rect(surface, rect, theme.CELL_COLOR, radius=18,
                             shadow_offset=6, shadow_alpha=80)
        title_surf = theme.font_large.render(title, True, theme.BUTTON_PRIMARY_DEEP)
        surface.blit(title_surf, title_surf.get_rect(
            midtop=(rect.centerx, rect.top + 30)))
        msg_surf = theme.font_small.render(message, True, theme.TEXT_SOFT)
        surface.blit(msg_surf, msg_surf.get_rect(
            midtop=(rect.centerx, rect.top + 90)))
        hint_surf = theme.font_tiny.render(
            "N: 새 게임    ESC: 메뉴", True, theme.TEXT_MUTE)
        surface.blit(hint_surf, hint_surf.get_rect(
            midbottom=(rect.centerx, rect.bottom - 18)))

    @staticmethod
    def draw_pause(surface: pygame.Surface, theme: ThemeManager):
        Popup.draw_overlay(surface, theme, "일시정지", "P를 눌러 계속하기")
