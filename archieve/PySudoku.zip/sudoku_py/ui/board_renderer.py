"""BoardRenderer — 따뜻한 3D 블럭 느낌의 보드 렌더링."""
import pygame
from typing import List, Optional, Set, Tuple

from .theme_manager import ThemeManager


class BoardRenderer:
    def __init__(self, theme: ThemeManager):
        self.t = theme

    def board_rect(self) -> pygame.Rect:
        total = self.t.CELL_SIZE * 9 + self.t.BLOCK_GAP * 2
        return pygame.Rect(
            self.t.GRID_OFFSET_X - 12,
            self.t.GRID_OFFSET_Y - 12,
            total + 24,
            total + 24,
        )

    def cell_rect(self, row: int, col: int) -> pygame.Rect:
        br, bc = row // 3, col // 3
        x = self.t.GRID_OFFSET_X + col * self.t.CELL_SIZE + bc * self.t.BLOCK_GAP
        y = self.t.GRID_OFFSET_Y + row * self.t.CELL_SIZE + br * self.t.BLOCK_GAP
        return pygame.Rect(x + 2, y + 2, self.t.CELL_SIZE - 4, self.t.CELL_SIZE - 4)

    def point_to_cell(self, pos: Tuple[int, int]) -> Optional[Tuple[int, int]]:
        x, y = pos
        for r in range(9):
            for c in range(9):
                if self.cell_rect(r, c).collidepoint(x, y):
                    return (r, c)
        return None

    def draw(
        self,
        surface: pygame.Surface,
        board_grid: List[List[int]],
        original: List[List[bool]],
        notes: List[List[Set[int]]],
        selected: Optional[Tuple[int, int]],
        error_cells: List[Tuple[int, int]],
    ):
        t = self.t
        # outer tray (recessed look)
        tray = self.board_rect()
        t.draw_soft_rect(surface, tray, t.BG_DEEP, radius=18, shadow_offset=5, shadow_alpha=70)

        # 3x3 block backgrounds (slight raised blocks)
        for br in range(3):
            for bc in range(3):
                block_rect = pygame.Rect(
                    t.GRID_OFFSET_X + bc * (t.CELL_SIZE * 3 + t.BLOCK_GAP) - 3,
                    t.GRID_OFFSET_Y + br * (t.CELL_SIZE * 3 + t.BLOCK_GAP) - 3,
                    t.CELL_SIZE * 3 + 6,
                    t.CELL_SIZE * 3 + 6,
                )
                t.draw_soft_rect(surface, block_rect, (217, 193, 154),
                                 radius=12, shadow_offset=3, shadow_alpha=50)

        sel_val = 0
        if selected is not None:
            sel_val = board_grid[selected[0]][selected[1]]

        error_set = set(error_cells)

        # cells
        for r in range(9):
            for c in range(9):
                rect = self.cell_rect(r, c)
                v = board_grid[r][c]
                fixed = original[r][c]

                # color
                if (r, c) in error_set:
                    color = t.ERROR_BG
                elif selected == (r, c):
                    color = t.SELECTED_COLOR
                elif selected is not None and sel_val != 0 and v == sel_val:
                    color = t.SAME_NUM_COLOR
                elif selected is not None and (
                    r == selected[0] or c == selected[1]
                    or (r // 3 == selected[0] // 3 and c // 3 == selected[1] // 3)
                ):
                    color = t.HIGHLIGHT_COLOR
                elif fixed:
                    color = t.CELL_FIXED_BG
                else:
                    color = t.CELL_COLOR

                t.draw_soft_rect(surface, rect, color,
                                 radius=8, shadow_offset=2, shadow_alpha=45)

                # number
                if v != 0:
                    if (r, c) in error_set:
                        col_color = t.ERROR_COLOR
                    elif fixed:
                        col_color = t.FIXED_NUM_COLOR
                    else:
                        col_color = t.USER_NUM_COLOR
                    text = t.font_cell.render(str(v), True, col_color)
                    tr = text.get_rect(center=rect.center)
                    surface.blit(text, tr)
                elif notes[r][c]:
                    self._draw_notes(surface, rect, notes[r][c])

    def _draw_notes(self, surface: pygame.Surface, cell_rect: pygame.Rect, marks: Set[int]):
        t = self.t
        sub_w = cell_rect.width / 3
        sub_h = cell_rect.height / 3
        for n in marks:
            i = (n - 1) // 3
            j = (n - 1) % 3
            x = cell_rect.x + sub_w * j + sub_w / 2
            y = cell_rect.y + sub_h * i + sub_h / 2
            surf = t.font_note.render(str(n), True, t.NOTE_COLOR)
            r = surf.get_rect(center=(int(x), int(y)))
            surface.blit(surf, r)
