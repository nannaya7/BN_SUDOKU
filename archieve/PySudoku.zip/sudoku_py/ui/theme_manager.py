"""ThemeManager — 따뜻한 3D 블럭 느낌의 색상 및 폰트 설정."""
import os
import pygame


class ThemeManager:
    # Window
    WIDTH = 640
    HEIGHT = 820

    # Board layout
    CELL_SIZE = 58
    GRID_OFFSET_X = 45
    GRID_OFFSET_Y = 110
    BLOCK_GAP = 8  # 3x3 블록 사이 간격

    # 따뜻한 톤 팔레트 (neumorphic cream/terracotta)
    BG_COLOR            = (242, 230, 211)   # 배경 cream
    BG_DEEP             = (220, 200, 170)   # 보드 트레이
    GRID_LINE           = (160, 125,  85)   # 블록 구분선
    CELL_COLOR          = (251, 240, 218)   # 셀 기본
    CELL_FIXED_BG       = (233, 210, 174)   # 고정 셀
    SELECTED_COLOR      = (249, 217, 180)   # 선택 (warm peach)
    HIGHLIGHT_COLOR     = (245, 227, 197)   # peer
    SAME_NUM_COLOR      = (243, 207, 162)   # 같은 숫자
    ERROR_BG            = (251, 217, 207)
    FIXED_NUM_COLOR     = ( 70,  54,  40)   # 고정 숫자
    USER_NUM_COLOR      = (163,  92,  50)   # 사용자 입력 (terracotta)
    ERROR_COLOR         = (200,  90,  74)
    NOTE_COLOR          = (167, 145, 122)
    TEXT_COLOR          = ( 70,  54,  40)
    TEXT_SOFT           = (122, 100,  80)
    TEXT_MUTE           = (167, 145, 122)

    BUTTON_COLOR        = (251, 240, 218)
    BUTTON_HOVER        = (245, 227, 197)
    BUTTON_ACTIVE       = (232, 207, 168)
    BUTTON_PRIMARY      = (211, 135,  85)
    BUTTON_PRIMARY_DEEP = (163,  92,  50)

    SHADOW_DARK         = ( 95,  60,  30)   # drop shadow
    SHADOW_LIGHT        = (255, 247, 232)

    def __init__(self):
        pygame.font.init()
        self.font_large = self._load(48, bold=True)
        self.font_medium = self._load(32, bold=True)
        self.font_cell = self._load(34, bold=True)
        self.font_small = self._load(20, bold=True)
        self.font_tiny = self._load(12, bold=True)
        self.font_note = self._load(12, bold=True)

    @staticmethod
    def _load(size: int, bold: bool = False) -> pygame.font.Font:
        # 한글 지원 시스템 폰트 시도
        candidates = [
            "Malgun Gothic", "AppleGothic", "NanumGothic",
            "Noto Sans CJK KR", "Noto Sans KR", "Arial Unicode MS"
        ]
        for name in candidates:
            try:
                path = pygame.font.match_font(name)
                if path:
                    f = pygame.font.Font(path, size)
                    f.set_bold(bold)
                    return f
            except Exception:
                continue
        f = pygame.font.SysFont(None, size, bold=bold)
        return f

    # 편의: neumorphic 그림자 렌더 헬퍼
    def draw_soft_rect(self, surface: pygame.Surface, rect: pygame.Rect,
                       color, radius: int = 10,
                       shadow_offset: int = 3,
                       shadow_alpha: int = 55):
        # drop shadow (dark)
        shadow = pygame.Surface((rect.width + shadow_offset * 2,
                                 rect.height + shadow_offset * 2), pygame.SRCALPHA)
        pygame.draw.rect(
            shadow,
            (*self.SHADOW_DARK, shadow_alpha),
            shadow.get_rect().inflate(-shadow_offset, -shadow_offset).move(shadow_offset, shadow_offset),
            border_radius=radius,
        )
        surface.blit(shadow, (rect.x - shadow_offset, rect.y - shadow_offset))
        # highlight (light) top-left
        hl = pygame.Surface((rect.width + shadow_offset * 2,
                             rect.height + shadow_offset * 2), pygame.SRCALPHA)
        pygame.draw.rect(
            hl,
            (*self.SHADOW_LIGHT, 130),
            hl.get_rect().inflate(-shadow_offset, -shadow_offset).move(-shadow_offset, -shadow_offset),
            border_radius=radius,
        )
        surface.blit(hl, (rect.x - shadow_offset, rect.y - shadow_offset))
        # main face
        pygame.draw.rect(surface, color, rect, border_radius=radius)
