"""GameWindow — 메인 Pygame 루프."""
import pygame
import sys
from typing import Optional

from core.game_state import GameSession, GameState
from .theme_manager import ThemeManager
from .board_renderer import BoardRenderer
from .ui_components import Button, NumberPad, StatusBar, Popup


class GameWindow:
    FPS = 60

    def __init__(self):
        pygame.init()
        self.theme = ThemeManager()
        self.screen = pygame.display.set_mode(
            (self.theme.WIDTH, self.theme.HEIGHT))
        pygame.display.set_caption("수도쿠 · Sudoku")
        self.clock = pygame.time.Clock()

        self.session = GameSession()
        self.session.new_game("easy")

        self.board_renderer = BoardRenderer(self.theme)
        self.status_bar = StatusBar(self.theme)

        t = self.theme
        # number pad
        pad_y = t.GRID_OFFSET_Y + 9 * t.CELL_SIZE + 2 * t.BLOCK_GAP + 20
        self.number_pad = NumberPad(
            t, (40, pad_y),
            on_input=self.session.input_number,
            on_erase=self.session.erase,
        )

        # action buttons row
        act_y = pad_y + 72
        bw, bh = 100, 36
        gap = 10
        self.btn_notes = Button(
            pygame.Rect(40, act_y, bw, bh), "Notes (N)", t,
            on_click=self.session.toggle_notes,
        )
        self.btn_hint = Button(
            pygame.Rect(40 + (bw + gap), act_y, bw, bh), "Hint (H)", t,
            on_click=self.session.hint,
        )
        self.btn_undo = Button(
            pygame.Rect(40 + 2 * (bw + gap), act_y, bw, bh), "Undo (U)", t,
            on_click=self.session.undo,
        )
        self.btn_pause = Button(
            pygame.Rect(40 + 3 * (bw + gap), act_y, bw, bh), "Pause (P)", t,
            on_click=self.session.toggle_pause,
        )
        self.btn_new = Button(
            pygame.Rect(40 + 4 * (bw + gap), act_y, bw + 20, bh), "새 게임", t,
            primary=True, on_click=self._cycle_new_game,
        )

    def _cycle_new_game(self):
        order = ["easy", "medium", "hard"]
        idx = order.index(self.session.difficulty) if self.session.difficulty in order else 0
        self.session.new_game(order[(idx + 1) % len(order)])

    def run(self):
        running = True
        while running:
            for ev in pygame.event.get():
                if ev.type == pygame.QUIT:
                    running = False
                self.handle_event(ev)
            self.draw()
            pygame.display.flip()
            self.clock.tick(self.FPS)

        pygame.quit()
        sys.exit(0)

    def handle_event(self, ev):
        s = self.session

        # buttons always handle hover/click
        for b in [self.btn_notes, self.btn_hint, self.btn_undo,
                  self.btn_pause, self.btn_new]:
            b.handle_event(ev)
        self.number_pad.handle_event(ev)

        # update toggle-button active states
        self.btn_notes.active = s.notes_mode

        if ev.type == pygame.MOUSEBUTTONDOWN and ev.button == 1:
            if s.state == GameState.PLAYING:
                cell = self.board_renderer.point_to_cell(ev.pos)
                if cell:
                    s.selected = cell

        if ev.type == pygame.KEYDOWN:
            k = ev.key
            if k == pygame.K_ESCAPE:
                s.new_game(s.difficulty)
                return

            if s.state == GameState.PAUSED and k != pygame.K_p:
                return
            if s.state in (GameState.WIN, GameState.GAME_OVER):
                if k == pygame.K_n:
                    s.new_game(s.difficulty)
                return

            if pygame.K_1 <= k <= pygame.K_9:
                s.input_number(k - pygame.K_0)
            elif pygame.K_KP1 <= k <= pygame.K_KP9:
                s.input_number(k - pygame.K_KP0)
            elif k in (pygame.K_BACKSPACE, pygame.K_DELETE, pygame.K_0):
                s.erase()
            elif k == pygame.K_UP:
                s.move_selection(-1, 0)
            elif k == pygame.K_DOWN:
                s.move_selection(1, 0)
            elif k == pygame.K_LEFT:
                s.move_selection(0, -1)
            elif k == pygame.K_RIGHT:
                s.move_selection(0, 1)
            elif k == pygame.K_n:
                s.toggle_notes()
            elif k == pygame.K_h:
                s.hint()
            elif k == pygame.K_u:
                s.undo()
            elif k == pygame.K_p:
                s.toggle_pause()

    def draw(self):
        t = self.theme
        s = self.session
        self.screen.fill(t.BG_COLOR)

        self.status_bar.draw(self.screen, s)

        if s.board is None:
            return

        errors = s.board.find_errors()
        self.board_renderer.draw(
            self.screen,
            s.board.grid,
            s.board.original,
            s.notes,
            s.selected,
            errors,
        )

        # number-count on pad
        counts = [0] * 10
        for r in range(9):
            for c in range(9):
                v = s.board.grid[r][c]
                if v:
                    counts[v] += 1
        self.number_pad.draw(self.screen, counts)

        self.btn_notes.active = s.notes_mode
        for b in [self.btn_notes, self.btn_hint, self.btn_undo,
                  self.btn_pause, self.btn_new]:
            b.draw(self.screen)

        if s.state == GameState.PAUSED:
            Popup.draw_pause(self.screen, t)
        elif s.state == GameState.WIN:
            Popup.draw_overlay(
                self.screen, t, "훌륭해요!",
                f"클리어 시간: {s.timer.format()}",
            )
        elif s.state == GameState.GAME_OVER:
            Popup.draw_overlay(
                self.screen, t, "게임 오버",
                f"실수 {s.mistakes}회 · N: 재도전",
            )
